from django.shortcuts import render,redirect
from django.http import HttpResponse
from urllib import request
from django.views import View
from .models import Product
from .models import Customer
from .models import Cart
# from home.models import Contact
from django.db.models import Count
from . forms import RegistrationForm,CustomerProfileForm
from django.contrib import messages
from django.http import JsonResponse
from django.db.models import Q
from django.contrib.auth.models import User

# from django.db.models import count
# Create your views here.
def home(request):
    return render(request,"diksha1/home.html")

def About(request):
    return render(request,"diksha1/about.html")

def Contact(request):
    if request.method =='POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        message = request.POST.get('message')
        contact = contact(name=name, email=email,message=message)
        contact.save()
        messages.success(request, "your message has been sent!")
    return render(request,"diksha1/contact.html")

class CategoryView(View):
    def get(self,request,val):
         product = Product.objects.filter(category=val)
         title = Product.objects.filter(category=val).values('title')
         return render(request,'diksha1/category.html',locals())
class CategoryTitle(View):
    def get(self,request,val):
        product = Product.objects.filter(title=val)
        title = Product.objects.filter(category=product[0].category).values('title')
        return render(request,'diksha1/category.html',locals())

class ProductDetail(View):
    def get(self,request,pk):
        product = Product.objects.get(pk=pk)
        return render(request,"diksha1/productdetail.html",locals())
    
class RegistrationView(View):
    def get(self,request):
        form= RegistrationForm()
        return render(request,'diksha1/registration.html',locals())
    def post(self,request):
        form=RegistrationForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"congratulation! User registered")
        else:
            messages.warning(request,"Invalid Input Data")
        return render(request,"diksha1/registration.html",locals())
    
class ProfileView(View):
    def get(self,request):
        form = CustomerProfileForm()
        return render(request, 'diksha1/profile.html',locals())
    def post(self,request):
        form = CustomerProfileForm(request.POST)
        if form.is_valid():
            user = request.user
            name = form.cleaned_data['name']
            locality = form.cleaned_data['locality']
            city = form.cleaned_data['city']
            mobile = form.cleaned_data['mobile']
            state = form.cleaned_data['state']
            zipcode = form.cleaned_data['zipcode']

            reg = Customer(user=user,name=name,locality=locality,
            mobile=mobile,city=city,state=state,zipcode=zipcode)
            reg.save()
            messages.success(request,"Congratulation! Profile saved successfully")
        else:
            messages.warning(request,"Invalid Input Date")
        return render(request,"diksha1/profile.html",locals())
def address(request):
     add=Customer.objects.filter(user=request.user)
     return render(request,"diksha1/address.html",locals())
class UpdateAddress(View):
        def get(self,request,pk):
            add=Customer.objects.get(pk=pk)
            form=CustomerProfileForm(instance=add)
            return render(request,"diksha1/Updateaddress.html",locals())
def post(self,request,pk):
    form=CustomerProfileForm(request.POST)
    if form.is_valid():
        add=Customer.objects.get(pk=pk)
        add.name=form.cleaned_data['name']
        add.locality=form.cleaned_data['locality']
        add.city=form.cleaned_data['city']
        add.mobile=form.cleaned_data['mobile']
        add.state=form.cleaned_data['state']
        add.zipcode=form.cleaned_data['zipcode']
        add.save()

        messages.success(request,"congratulations! Profile Update successfully")
    else:
        messages.warning(request,"Invalid Input Data")
        return redirect("address")
    
def add_to_cart(request):
    user = request.user
    product_id = request.GET.get('prod_id')
    product = Product.objects.get(id=product_id)
    Cart(user=user,product=product).save()
    return redirect("/cart")


def show_cart(request):
    user = request.user
    cart = Cart.objects.filter(user=user)
    amount=0
    for p in cart:
        value = p.quantity * p.product.discounted_price
        amount = amount + value
    totalamount = amount + 40
    return render(request,'diksha1/addtocart.html',locals())

class checkout(View):
    def get(self,request):
        user=request.user
        add=Customer.objects.filter(user=user)
        return render(request,'app/checkout.html',locals(()))


def plus_cart(request):
    if request.method =="GET":
        prod_id=request.GET['prod_id']
        c = Cart.objects.get(Q(product=prod_id)& Q(user=request.user))
        c.quantity+=1
        user=request.User
        cart=Cart.objects.filter(user=user)
        amount = 0
        for p in cart:
            value = p.quantity * p.product.discounted_price
            amount = amount + value
        totalamount = amount + 50
        data= {
            'quantity':c.quantity,
            'amount':amount,
            'totalamount':totalamount
        }
        return JsonResponse(data)
    
def minus_cart(request):
    if request.method =="GET":
        prod_id=request.GET['prod_id']
        c = Cart.objects.get(Q(product=prod_id)& Q(user=request.user))
        c.quantity-=1
        user=request.User
        cart=Cart.objects.filter(user=user)
        amount = 0
        for p in cart:
            value = p.quantity * p.product.discounted_price
            amount = amount + value
        totalamount = amount + 50
        data= {
            'quantity':c.quantity,
            'amount':amount,
            'totalamount':totalamount
        }
        return JsonResponse(data)

def remove_cart(request):
    if request.method =="GET":
        prod_id=request.GET['prod_id']
        c = Cart.objects.get(Q(product=prod_id)& Q(user=request.user))
        c.delete()
        user=request.User
        cart=Cart.objects.filter(user=user)
        amount = 0
        for p in cart:
            value = p.quantity * p.product.discounted_price
            amount = amount + value
        totalamount = amount + 50
        data= {
            'quantity':c.quantity,
            'amount':amount,
            'totalamount':totalamount
        }
        return JsonResponse(data)
    

class Checkout(View):
    def get(self,request):
        user = request.user
        add = Customer.objects.filter(user=user)
        cart_items=Cart.objects.filter(user=user)
        famout = 0
        for p in cart_items:
            value = p.quantity * p.product.discounted_price
            famount = famount + value
        totalamount = famout + 40
        return render(request,"kar/checkout.html",locals())


    